using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class Chatting : MonoBehaviour
{
    public TMP_Text whereText;
    public TMP_Text itemNameText;
    public TMP_Text nameText;
    public TMP_Text gradeText;

    public Color[] textColor;
    public Dictionary<int, Color> dicColor = new Dictionary<int, Color>();

    private string[] nameStrs = {"A", "B", "C", "D", "E"};
    private string[] whereStrs = { "���޿�����ȯ", "�Ϲݿ�����ȯ","[7-7] ��������","��ȭ", "�ռ�" };
    private string[] itemStrs = { "�ѿ��", "����� ��޺� ����", "��� ������"};
    // Start is called before the first frame update
    void Start()
    {
        dicColor.Add(4, new Color32(244, 140, 0, 255));
        dicColor.Add(5, new Color32(159, 18, 15, 255));
        dicColor.Add(6, new Color32(121, 49, 97, 255));


    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.F8))
        {
            nameText.text = nameStrs[Random.Range(0, nameStrs.Length)];
            whereText.text = whereStrs[Random.Range(0, whereStrs.Length)];
            int grade = Random.Range(4, 7);
            gradeText.text = $"X{grade}";
            itemNameText.text = itemStrs[Random.Range(0, itemStrs.Length)];

            itemNameText.color = textColor[grade];
            itemNameText.color = dicColor[grade];

        }
    }
}
