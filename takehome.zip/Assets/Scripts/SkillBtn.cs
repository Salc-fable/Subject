using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class SkillBtn : MonoBehaviour
{
    public float totalTime;

    private Image iconimg;
    private GameObject skillObj;
    private Image skillObjImg;
    private TMP_Text skillText;
    //private TextMeshProUGUI

    public float timer = -1;
    public float maxTime;

    void Start()
    {
        iconimg = transform.GetChild(0).GetComponent<Image>();
        skillObj = transform.GetChild(1).gameObject;
        skillObjImg = transform.GetChild(1).GetComponent<Image>();
        skillText = transform.GetChild(1).GetChild(0).GetComponent<TMP_Text>();

    }

    
    void Update()
    {
        if(timer>=0)
        {
            timer -= Time.deltaTime;
            skillObjImg.fillAmount = timer / maxTime;
            if (timer>1)
            {
                skillText.text = $"{(int)timer}";
            }
            else
            {
                skillText.text = $"{timer.ToString("0.#")}";
                
            }
        }
        else
        {
            skillObj.SetActive(false);
        }
    }

    public void OnStart(float time)
    {
        skillObjImg.fillAmount = 1;
        maxTime = time;
        timer = time;
        skillObj.SetActive(true);
        
    }
}
