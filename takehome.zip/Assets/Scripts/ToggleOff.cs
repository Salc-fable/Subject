using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ToggleOff : MonoBehaviour
{
    [SerializeField] private GameObject Option;
    public void CloseOption()
    {
        Option.SetActive(false);
    }
}
