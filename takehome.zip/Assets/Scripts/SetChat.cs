using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class SetChat : MonoBehaviour
{
    [SerializeField]
    public GameObject chatprefab;
    public TMP_Text chat;
    
    private string[] Username = {"user1", "user2" , "user3" , "user4" , "user5", "user6"};
    private string[] Item = { "ItemA", "ItemB", "ItemC", "ItemD", "ItemE", "ItemF" };
    private string[] Place = { "Place1", "Place2", "Place3", "Place4", "Place5", "Place6" };

    

    void Start()
    {
        AddChat();
    }

    
    void Update()
    {
        
    }

    public void AddChat()
    {

        //<>{}<>
        chat.text = $"<color=red>{Username[0]}</color>";
    }

}
