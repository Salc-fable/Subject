using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float pSpeed = 5f;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        float x = Input.GetAxisRaw("Horizontal");
        float z = Input.GetAxisRaw("Vertical");
        transform.Translate(new Vector3(x, 0f, z) * Time.deltaTime * pSpeed);
    }
    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("Key1"))
        {
            Way1 w = GameObject.FindObjectOfType<Way1>();
            w.WayUp();

            Destroy(other.gameObject);
            
        }
        else if (other.CompareTag("Key2"))
        {
            Way2 w = GameObject.FindObjectOfType<Way2>();
            w.WayUp();

            Destroy(other.gameObject);

        }
        else if (other.CompareTag("Key3"))
        {
            Way3 w = GameObject.FindObjectOfType<Way3>();
            w.WayUp();

            Destroy(other.gameObject);

        }
        else if (other.CompareTag("Trap"))
        {
            transform.position = new Vector3(-18, 2, -18);
        }
    }
}
