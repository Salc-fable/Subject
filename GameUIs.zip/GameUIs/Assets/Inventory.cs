using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Linq;
using System.Collections.Generic;

public class Inventory : MonoBehaviour
{
    public TMP_Dropdown sortDropdown; 
    public GameObject itemPrefab;
    public Transform content;
    public Sprite[] gradeSprites;
    public Sprite[] consumableSprites;
    public Sprite[] weaponSprites;
    public Sprite[] armorSprites;

    [SerializeField]
    private Toggle[] toggles;
    

    private Dictionary<ItemType, Sprite[]> itemSpritePool;
    private List<ItemData> itemList = new List<ItemData>();
    private List<ItemData> deleteList = new List<ItemData>();   
    

    private int toggleType = 0;

    

    void Start()
    {
        itemSpritePool = new Dictionary<ItemType, Sprite[]>
        {
            { ItemType.Weapon, weaponSprites },
            { ItemType.Armor, armorSprites },
            { ItemType.Consumable, consumableSprites }
        };

        
        sortDropdown.onValueChanged.AddListener(SortItems);
        SortItems(sortDropdown.value);
    }

    private void Update()
    {
        

        if (Input.GetKeyDown(KeyCode.F1))
        {
            CreateRandomItem();
            SortItems(sortDropdown.value);
        }
        if(Input.GetKeyDown(KeyCode.F2))
        {
            foreach (var item in itemList)
            {
                if(item.isDeletable)
                {
                    deleteList.Add(item);
                }
            }
            foreach(var item in deleteList)
            {
                itemList.Remove(item);
            }
            SortItems(sortDropdown.value);
        }

       



    }

    public void CreateRandomItem()
    {
        ItemGrade grade = (ItemGrade)Random.Range(0, System.Enum.GetValues(typeof(ItemGrade)).Length);
        ItemType type = (ItemType)Random.Range(0, System.Enum.GetValues(typeof(ItemType)).Length);
        Sprite itemSprite = GetRandomSprite(type);

        if (type == ItemType.Consumable)
        {
            grade = 0;
            HandleConsumableItem(grade, type, itemSprite);
        }
        else
        {
            AddItem(new ItemData(grade, type, itemSprite, Random.Range(0, 100), Random.Range(80, 101), 0));
        }
    }

    private void HandleConsumableItem(ItemGrade grade, ItemType type, Sprite itemSprite)
    {
        foreach (var item in itemList)
        {
            if (item.Type == ItemType.Consumable && item.Image == itemSprite)
            {
                item.StackCount += 1;
                UpdateItemUI(item);
                return;
            }
        }

        AddItem(new ItemData(grade, type, itemSprite, 0, 0, 1));
    }

    private void AddItem(ItemData itemData)
    {
        itemList.Add(itemData);
        CreateItemUI(itemData);
    }

    private void CreateItemUI(ItemData itemData)
    {
        GameObject newItem = Instantiate(itemPrefab, content);

        Image background = newItem.GetComponent<Image>();
        background.sprite = gradeSprites[(int)itemData.Grade];

        Transform itemImageTransform = newItem.transform.Find("ItemImg");
        Image itemImage = itemImageTransform.GetComponent<Image>();
        itemImage.sprite = itemData.Image;

        Transform levelTextTransform = newItem.transform.Find("ItemLV");
        Transform enhanceTextTransform = newItem.transform.Find("ItemEnhance");
        Transform stackTextTransform = newItem.transform.Find("ItemStack");

        if (itemData.Type == ItemType.Consumable)
        {
            levelTextTransform.gameObject.SetActive(false);
            enhanceTextTransform.gameObject.SetActive(false);
            stackTextTransform.gameObject.SetActive(true);
            stackTextTransform.GetComponent<TMP_Text>().text = $"x{itemData.StackCount}";
            return;
        }
        
        levelTextTransform.gameObject.SetActive(true);
        enhanceTextTransform.gameObject.SetActive(true);
        stackTextTransform.gameObject.SetActive(false);
        levelTextTransform.GetComponent<TMP_Text>().text = $"Lv. {itemData.Level}";
        enhanceTextTransform.GetComponent<TMP_Text>().text = $"+{itemData.EnhanceValue}";
        
    }

    private void UpdateItemUI(ItemData itemData)
    {
        foreach (Transform child in content)
        {
            Transform itemImageTransform = child.Find("ItemImg");
            Image itemImage = itemImageTransform.GetComponent<Image>();

            if (itemImage.sprite == itemData.Image)
            {
                Transform stackTextTransform = child.Find("ItemStack");
                TMP_Text stackText = stackTextTransform.GetComponent<TMP_Text>();
                stackText.text = $"x{itemData.StackCount}";
                return;
            }
        }
    }

    private Sprite GetRandomSprite(ItemType type)
    {
        Sprite[] sprites = itemSpritePool[type];
        return sprites[Random.Range(0, sprites.Length)];
    }

    private void ToggleType()
    {
        for(int i=0;i<4;i++)
        {
            if(toggles[i].isOn)
            {
                toggleType = i;
            }
        }
    }
    public void OnToggle()
    {
        ToggleType();
        SortItems(sortDropdown.value);
    }
    // ������ ����
    private void SortItems(int index)
    {
        
        switch (index)
        {
            
            case 0: 
                itemList = itemList.OrderBy(item => item.Grade).ToList();
                break;
            case 1: 
                itemList = itemList.OrderByDescending(item => item.Grade).ToList();
                break;
            case 2: 
                itemList = itemList.OrderBy(item => item.Type).ToList();
                break;
        }

        // ���� UI ����
        foreach (Transform child in content)
        {
            Destroy(child.gameObject);
        }

        // ���ĵ� ���������� UI �ٽ� ����
        foreach (var item in itemList)
        {   if (toggleType!=0)
            {
                if(item.Type == (ItemType)toggleType-1)
                    CreateItemUI(item);
            }
            else
            { CreateItemUI(item); }
            
        }
    }

    
    
}
