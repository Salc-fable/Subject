using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ToggleInventory : MonoBehaviour
{
    public GameObject inventory;
    public GameObject on;

    
    void Update()
    {
        if (inventory.activeSelf)
        { 
            on.SetActive(false); 
        }
        else 
        { 
            on.SetActive(true); 
        }
        if(Input.GetKeyDown(KeyCode.I))
        {
            ToggleState();
        }
    }
    public void ToggleState()
    {
        inventory.SetActive(!inventory.activeSelf);
    }
}
