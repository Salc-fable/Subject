using JetBrains.Annotations;
using UnityEngine;

public enum ItemType { Consumable, Weapon, Armor }
public enum ItemGrade { Normal, Rare, Epic, Legendary, Ancient }

[System.Serializable]
public class ItemData
{
    public ItemGrade Grade;
    public ItemType Type;
    public Sprite Image;

    public int EnhanceValue;
    public int Level;
    public int StackCount;
    public bool isDeletable;

    // ������
    public ItemData(ItemGrade grade, ItemType type, Sprite image, int enhanceValue, int level, int stackCount = 0)
    {
        Grade = grade;
        Type = type;
        Image = image;
        EnhanceValue = enhanceValue;
        Level = level;
        StackCount = stackCount;
        isDeletable = false; 

    }
    
}
