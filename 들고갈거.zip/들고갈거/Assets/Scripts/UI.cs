using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEditor;
using Unity.Mathematics;

public class UI : MonoBehaviour
{
    //��ų
    [SerializeField] private Image[] CoolDown= new Image[4];
    [SerializeField] private float[] setCool = new float[4];
    [SerializeField] private TMP_Text[] TmpCool = new TMP_Text[4];
    [SerializeField] private float[] setSP = new float[4];
    //HP
    [SerializeField] private TMP_Text TextHP;
    [SerializeField] private Image BarHP;
    [SerializeField] public float MaxHP;
    [SerializeField] public float hpgen;
    [SerializeField] public float hpgenDelay;
    //SP
    [SerializeField] private TMP_Text TextSP;
    [SerializeField] private Image BarSP;
    [SerializeField] public float MaxSP;
    [SerializeField] public float spgen;
    [SerializeField] public float spgenDelay;

    [SerializeField]private GameObject SPW;
    [SerializeField] private GameObject COOLW;


    float hp = 0f;
    float sp = 0f;
    KeyCode[] KeyCodes = {KeyCode.Q,KeyCode.W,KeyCode.E,KeyCode.R};
    bool[] isCool = new bool[] { false, false , false , false };
    private float[] Cool = new float[] {0f,0f,0f,0f};
    

    void Start()
    {
        //��ų ���� �ʱ�ȭ
        for(int i=0;i<4;i++)
        {
            isCool[i] = false;
            Cool[i]= 0f;
            CoolDown[i].fillAmount =0;
            TmpCool[i].text =$"";
        }

        hp = MaxHP;
        HPset();
        StartCoroutine(HPGen());

        sp = MaxSP;
        SPset();
        StartCoroutine(SPGen());
    }

    
    void Update()
    {
        for ( int i=0;i<4; i++)
        {
            if (Input.GetKeyDown(KeyCodes[i]))
            {
                if (!isCool[i])
                {
                    if (sp>setSP[i])
                    {
                        sp -= setSP[i];
                        SPset();
                        StartCoroutine(Cooldown(i));
                    }
                    else if (setSP[i]>sp)
                    {
                        StartCoroutine(SPWarn());
                    }
                }
                else 
                {
                    StartCoroutine(COOLWarn());
                }
                
                
            }
        }
        if (Input.GetKeyDown(KeyCode.H))
        {
            if (hp>0)
            {
                hp-=30;
                if (hp<0)
                {
                    hp=1;
                }
                HPset();

            }
        }

    }

    //UI HP,SP ������
    void SPset()
    {
        TextSP.text =$"{(int)sp}/{MaxSP}";
        BarSP.fillAmount = sp/MaxSP;
    }
    void HPset()
    {
        TextHP.text =$"{(int)hp}/{MaxHP}";
        BarHP.fillAmount = hp/MaxHP;
    }
    
    //��ų ���(Q~R)
    IEnumerator Cooldown(int i)
    {
        isCool[i] = true;
        Cool[i] = 0f;
        CoolDown[i].fillAmount = 1;   
        
        while (setCool[i] - Cool[i]>1)
        {
            Cool[i] += Time.deltaTime;
            CoolDown[i].fillAmount = 1 - (Cool[i] / setCool[i]);
            TmpCool[i].text = $"{(int)(setCool[i] - Cool[i])}S";             

            yield return null;          
        }
        while ((setCool[i] - Cool[i]>0)&&(setCool[i] - Cool[i]<=1))
        {
            Cool[i] += Time.deltaTime;
            CoolDown[i].fillAmount = 1 - (Cool[i] / setCool[i]);
            TmpCool[i].text = $"{(setCool[i] - Cool[i]).ToString("F1")}S";

            yield return null;
        }

        CoolDown[i].fillAmount = 0;
        TmpCool[i].text = "";
        isCool[i] = false;
    }
    //HP, SP ���
    IEnumerator HPGen()
    {
        while (true)
        {
            yield return new WaitForSeconds(hpgenDelay); 

            if (hp < MaxHP) 
            {
                hp += hpgen;

                if (hp > MaxHP) 
                {
                    hp = MaxHP;
                }

                HPset();
            }
        }
    }
    IEnumerator SPGen()
    {
        while (true)
        {
            yield return new WaitForSeconds(spgenDelay);

            if (sp < MaxSP)
            {
                sp += spgen;

                if (sp > MaxSP)
                {
                    sp = MaxSP;
                }

                SPset();
            }
        }
    }
    IEnumerator SPWarn()
    {
        SPW.SetActive(true);
        yield return new WaitForSeconds(2f);
        SPW.SetActive(false);
    }
    IEnumerator COOLWarn()
    {
        COOLW.SetActive(true);
        yield return new WaitForSeconds(2f);
        COOLW.SetActive(false);
    }

}
